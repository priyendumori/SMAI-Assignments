import numpy as np
import csv
import random
 
 
 
################################# k fold cross validation ###############
def cross_validation(data,k):
    dataCopy = list(data)
    splitSize = len(data)//k
    testData = []
     
    for i in xrange(k):
        temp = []
        for j in xrange(splitSize):
            index = random.randrange(0,len(dataCopy))
            temp.append(dataCopy.pop(index))
        testData.append(temp)
     
    return testData
 
 
################################ genrating one hot vectors ##################
def labeling(Y,labels,flag):
    oneHot = np.zeros((Y.shape[0],labels))
    for i in xrange(Y.shape[0]):
        if flag:
            oneHot[i][Y[i]] = 1.0
 
        else:
            oneHot[i][Y[i]-1] = 1.0
     
    return oneHot
 
 
################################# BACK PROPAGATION ###################
 
def backPropagation(X,Y,hiddenLayerActivations,output,wh,bh,wout,bout,eita,activationFunction,regLambda):
    EoutLayer = (output - Y)/output.shape[0]
     
    delWOut = np.dot(hiddenLayerActivations.T,EoutLayer)
    delBOut = np.sum(EoutLayer,axis=0,keepdims=True)
     
    if activationFunction == 'tanh':
        tanPrime = tanh_Derivative(hiddenLayerActivations)
        EhiddenLayer = np.multiply(tanPrime,EoutLayer.dot(wout.T))
 
    elif activationFunction == 'sigmoid':
        sigPrime = sigmoid_func_Derivative(hiddenLayerActivations)
        EhiddenLayer = np.multiply(sigPrime,EoutLayer.dot(wout.T))
     
    delWH = np.dot(X.T,EhiddenLayer)
    delBH = np.sum(EhiddenLayer,axis=0,keepdims=True)
     
    wout -= (eita*delWOut)
    bout -= (eita*delBOut)
    wh -= (eita*delWH)
    bh -= (eita*delBH)
 
 
 
def sigmoid_func(x):
    return .5 * (1 + np.tanh(.5 * x))
 
def tanh_Derivative(x):
    return 1.0 - np.tanh(x) ** 2
 
def sigmoid_func_Derivative(x):
    return (sigmoid_func(x)*(1.0-sigmoid_func(x)))  
 
 
################################## FEED FORWARD NEURAL NETWORK ##################
 
def feed_forward_neural_network(eita,X,wh,wout,bh,bout,activationFunction):
    hiddenLayerInput = np.dot(X,wh)
     
    if activationFunction.lower() == 'tanh':
        hiddenLayerActivations = np.tanh(hiddenLayerInput + bh)
     
    elif activationFunction.lower() == 'sigmoid':
        hiddenLayerActivations = sigmoid_func(hiddenLayerInput + bh)
     
    outputLayerInput = np.dot(hiddenLayerActivations,wout) + bout
    outputProbs = softmax(outputLayerInput)
     
    return hiddenLayerActivations,outputProbs
 
 
def loss_function(output,Y):
    index = np.argmax(Y,axis=1).astype(int)
    predProb = output[np.arange(len(output)),index]
     
    logPreds = np.log(predProb)
    loss = -1.0 * float(np.sum(logPreds))/len(logPreds)
     
    return loss
 
 
################################## SOFTMAX ON OUTPUT LAYER #################
 
def softmax(outputArray):
    expScores = np.exp(outputArray)
    outputProbs = expScores / np.sum(expScores,axis=1,keepdims=True)
     
    return outputProbs
 
 
def regularizationSoftmaxLoss(regLambda,wh,wout):
    w1loss = 0.5 * regLambda * np.sum(wh*wh)
    w2loss = 0.5 * regLambda * np.sum(wout*wout)
    wloss = w1loss + w2loss
     
    return wloss 
 
 
 
 
 
 
################################ Testing Neural Network #####################
 
def predict_accuracy(predictions,labels):
    preds = np.argmax(predictions,1) == np.argmax(labels,1)
    correct = np.sum(preds)
    accuracy = 100.0 * float(correct)/predictions.shape[0]
     
    return accuracy
